# Ajebo backend proxy

This tiny Express server is the **secure** way to connect the Ajebo Android app
to Claude. It holds your real Anthropic API key as a server-side environment
variable — the key never ships inside the APK and can't be extracted by
decompiling the app.

```
Ajebo Android app  --HTTPS-->  this backend  --HTTPS + secret key-->  api.anthropic.com
```

## Why this exists

Any secret compiled into an Android app (even "hidden" in `BuildConfig`,
obfuscated with ProGuard, or loaded from a native `.so`) can be extracted by
someone who decompiles the APK. There is no fully secure way to embed a
long-lived secret API key in an app you distribute publicly. The standard,
correct fix is to move the secret behind a server you control, and have the
app talk to that server instead.

## Run it locally

```bash
cd backend
cp .env.example .env       # then edit .env and paste your real Anthropic API key
npm install
npm start
```

The server listens on `http://localhost:3000` by default, with the chat
endpoint at `POST /api/chat`.

## Deploy it

Deploy this folder (just `server.js` + `package.json`) to any Node.js host,
for example:

- **Render / Railway / Fly.io** — connect the repo (or this folder), set the
  `ANTHROPIC_API_KEY` environment variable in the dashboard, deploy.
- **A VPS** — `npm install --production && npm start` behind a reverse proxy
  (nginx/Caddy) with HTTPS (e.g. via Let's Encrypt).
- **Serverless** (AWS Lambda + API Gateway, Google Cloud Run, etc.) — wrap the
  same request-handling logic in the platform's handler signature; the request/
  response shapes stay identical.

Whatever you choose, you need:

1. `ANTHROPIC_API_KEY` set as a secret environment variable on the host (never
   in code, never in a committed file).
2. HTTPS on the public URL (Ajebo's Android network security config refuses
   plain HTTP).
3. The resulting URL, e.g. `https://your-app.onrender.com/api/chat`, pasted
   into Ajebo's **Settings → AI/API Settings → Backend proxy URL** field.

## Request / response contract

**Request** (from the Ajebo app):
```json
{
  "messages": [
    { "role": "user", "content": "Hi!" },
    { "role": "assistant", "content": "Hello! How can I help?" },
    { "role": "user", "content": "What's the weather like on Mars?" }
  ]
}
```

**Response**:
```json
{ "reply": "On Mars, average temperatures hover around -80°F (-60°C)..." }
```

Errors return a non-2xx status with `{ "error": "..." }`, which the Android
client surfaces to the user.

## Hardening ideas for production

- Add authentication (an API key or signed token the app sends, checked here)
  so random people can't rack up your Anthropic bill.
- Tighten the rate limiter in `server.js` to your expected usage.
- Log requests (without message content) for abuse monitoring.
- Put this behind Cloudflare or a similar edge/CDN layer for DDoS protection.
