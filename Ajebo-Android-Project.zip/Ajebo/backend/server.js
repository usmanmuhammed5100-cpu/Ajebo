/**
 * Ajebo backend proxy
 * ---------------------------------------------------------------------
 * This is the SECURE way to give the Ajebo Android app access to Claude.
 * The real Anthropic API key lives only here, as a server-side environment
 * variable, and is never compiled into or shipped inside the APK.
 *
 * The Android app sends: { "messages": [{ "role": "user"|"assistant", "content": "..." }, ...] }
 * This server adds the API key, calls Anthropic, and returns: { "reply": "..." }
 *
 * Deploy this anywhere that can hold a secret environment variable and run
 * Node.js — e.g. Render, Railway, Fly.io, a small VPS, AWS Lambda + API
 * Gateway, Google Cloud Run, etc. It does NOT belong inside the Android
 * project or the APK.
 */

const express = require('express');
const rateLimit = require('express-rate-limit');

const app = express();
app.use(express.json({ limit: '256kb' }));

const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
const CLAUDE_MODEL = process.env.CLAUDE_MODEL || 'claude-sonnet-4-6';
const PORT = process.env.PORT || 3000;

if (!ANTHROPIC_API_KEY) {
  console.error('FATAL: ANTHROPIC_API_KEY environment variable is not set.');
  process.exit(1);
}

// Basic abuse protection — tune to your expected usage.
app.use(
  '/api/chat',
  rateLimit({
    windowMs: 60 * 1000,
    max: 20,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many requests, please slow down.' }
  })
);

const SYSTEM_PROMPT =
  'You are Ajebo, a friendly, concise personal AI assistant living inside an Android app. ' +
  'Keep replies short and conversational, suitable for a phone chat bubble.';

app.post('/api/chat', async (req, res) => {
  try {
    const { messages } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Request must include a non-empty "messages" array.' });
    }

    // Keep the payload sane: cap history length and message size server-side too,
    // regardless of what the client already trimmed.
    const trimmed = messages.slice(-20).map((m) => ({
      role: m.role === 'assistant' ? 'assistant' : 'user',
      content: String(m.content ?? '').slice(0, 4000)
    }));

    const anthropicResponse = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: CLAUDE_MODEL,
        max_tokens: 1024,
        system: SYSTEM_PROMPT,
        messages: trimmed
      })
    });

    const data = await anthropicResponse.json();

    if (!anthropicResponse.ok) {
      const message = data?.error?.message || 'Upstream AI request failed.';
      return res.status(anthropicResponse.status).json({ error: message });
    }

    const reply = (data.content || [])
      .filter((block) => block.type === 'text')
      .map((block) => block.text)
      .join('');

    return res.json({ reply });
  } catch (err) {
    console.error('Ajebo backend error:', err);
    return res.status(500).json({ error: 'Internal server error.' });
  }
});

app.get('/health', (_req, res) => res.json({ status: 'ok' }));

app.listen(PORT, () => {
  console.log(`Ajebo backend proxy listening on port ${PORT}`);
});
