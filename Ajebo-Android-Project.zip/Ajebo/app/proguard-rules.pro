# Ajebo ProGuard rules

# Keep OkHttp / okio internals used via reflection
-dontwarn okhttp3.**
-dontwarn okio.**
-keepattributes Signature
-keepattributes *Annotation*

# org.json.* classes come from the Android platform (android.jar), not from
# a bundled dependency, so there is nothing of ours to keep for them.

# Keep our data models (parsed with org.json manually, but keep for safety)
-keep class com.ajebo.assistant.data.** { *; }
