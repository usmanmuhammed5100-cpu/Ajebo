package com.ajebo.assistant.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "ajebo_settings")

/**
 * Stores user-configurable settings: whether TTS is on, dark/light theme, and
 * (optionally) a user-supplied backend URL / API key override entered in Settings
 * rather than compiled into the app. This keeps secrets out of source control and
 * lets a shared APK be reconfigured per-installation without a rebuild.
 */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val TTS_ENABLED = booleanPreferencesKey("tts_enabled")
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val BACKEND_URL = stringPreferencesKey("backend_url")
        val API_KEY = stringPreferencesKey("api_key") // dev/testing override only
    }

    val ttsEnabled: Flow<Boolean> =
        context.dataStore.data.map { it[Keys.TTS_ENABLED] ?: true }

    val darkTheme: Flow<Boolean> =
        context.dataStore.data.map { it[Keys.DARK_THEME] ?: false }

    val backendUrl: Flow<String> =
        context.dataStore.data.map { it[Keys.BACKEND_URL] ?: "" }

    val apiKeyOverride: Flow<String> =
        context.dataStore.data.map { it[Keys.API_KEY] ?: "" }

    suspend fun setTtsEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.TTS_ENABLED] = enabled }
    }

    suspend fun setDarkTheme(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DARK_THEME] = enabled }
    }

    suspend fun setBackendUrl(url: String) {
        context.dataStore.edit { it[Keys.BACKEND_URL] = url }
    }

    suspend fun setApiKeyOverride(key: String) {
        context.dataStore.edit { it[Keys.API_KEY] = key }
    }
}
