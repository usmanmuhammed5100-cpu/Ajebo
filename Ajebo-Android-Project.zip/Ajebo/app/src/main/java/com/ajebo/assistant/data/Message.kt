package com.ajebo.assistant.data

/**
 * Who a chat message came from.
 */
enum class Sender {
    USER,
    AJEBO,
    SYSTEM // used for action confirmations / errors, styled distinctly in the UI
}

/**
 * A single message bubble in the conversation.
 */
data class Message(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val sender: Sender,
    val timestamp: Long = System.currentTimeMillis(),
    val isError: Boolean = false
)
