package com.ajebo.assistant.actions

import java.util.Calendar
import java.util.Locale
import java.util.regex.Pattern

/**
 * Minimal, dependency-free parser for the time expressions Ajebo needs to understand:
 * "at 6 PM", "at 6:30 am", "at 18:00", and "in 20 minutes" / "in 2 hours".
 * This intentionally does not try to be a full NLP date parser — it covers the
 * patterns named in the spec and fails gracefully (returns null) otherwise.
 */
object TimeParser {

    private val CLOCK_TIME_PATTERN: Pattern = Pattern.compile(
        "\\b(?:at|for)\\s+(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?\\b",
        Pattern.CASE_INSENSITIVE
    )

    private val DURATION_PATTERN: Pattern = Pattern.compile(
        "\\bin\\s+(\\d{1,3})\\s*(minute|minutes|min|hour|hours|hr|hrs)\\b",
        Pattern.CASE_INSENSITIVE
    )

    /** Returns (hour24, minute) for use with AlarmClock.EXTRA_HOUR/EXTRA_MINUTES, or null. */
    fun extractClockTime(text: String): Pair<Int, Int>? {
        val matcher = CLOCK_TIME_PATTERN.matcher(text)
        if (!matcher.find()) return null

        var hour = matcher.group(1)?.toIntOrNull() ?: return null
        val minute = matcher.group(2)?.toIntOrNull() ?: 0
        val meridiem = matcher.group(3)?.lowercase(Locale.getDefault())

        if (hour !in 0..23 || minute !in 0..59) return null

        if (meridiem == "pm" && hour < 12) hour += 12
        if (meridiem == "am" && hour == 12) hour = 0
        // No am/pm given and hour <= 7: assume it means the next occurring one is more useful
        // as a 24h value if hour > 12 already; otherwise leave as-is (e.g. "at 14" -> 14:00).

        return hour to minute
    }

    /**
     * Resolves a time or duration phrase found in [text] to an absolute future timestamp
     * in millis. Clock times ("at 6 PM") resolve to the next occurrence of that time
     * (today if still ahead, otherwise tomorrow). Durations ("in 20 minutes") are relative
     * to now. Returns null if no recognizable time expression is found.
     */
    fun extractFutureMillis(text: String): Long? {
        val durationMatcher = DURATION_PATTERN.matcher(text)
        if (durationMatcher.find()) {
            val amount = durationMatcher.group(1)?.toLongOrNull() ?: return null
            val unit = durationMatcher.group(2)?.lowercase(Locale.getDefault()).orEmpty()
            val millis = if (unit.startsWith("hour") || unit.startsWith("hr")) {
                amount * 60L * 60L * 1000L
            } else {
                amount * 60L * 1000L
            }
            return System.currentTimeMillis() + millis
        }

        val clockTime = extractClockTime(text) ?: return null
        val (hour, minute) = clockTime

        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (calendar.timeInMillis <= System.currentTimeMillis()) {
            calendar.add(Calendar.DAY_OF_YEAR, 1)
        }
        return calendar.timeInMillis
    }

    /** Removes the recognized time phrase from [text], leaving just the task description. */
    fun stripTimePhrase(text: String): String {
        var result = DURATION_PATTERN.matcher(text).replaceAll("").trim()
        result = CLOCK_TIME_PATTERN.matcher(result).replaceAll("").trim()
        return result.trim().trimEnd(',', '.', ' ').ifBlank { "your reminder" }
    }
}
