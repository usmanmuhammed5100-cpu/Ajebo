package com.ajebo.assistant

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.ajebo.assistant.data.ChatViewModel
import com.ajebo.assistant.data.UiEvent
import com.ajebo.assistant.speech.SpeechRecognitionManager
import com.ajebo.assistant.speech.TextToSpeechManager
import com.ajebo.assistant.ui.screens.ChatScreen
import com.ajebo.assistant.ui.screens.SettingsScreen
import com.ajebo.assistant.ui.theme.AjeboTheme
import kotlinx.coroutines.flow.collectLatest

private enum class Screen { CHAT, SETTINGS }

class MainActivity : ComponentActivity() {

    private val viewModel: ChatViewModel by viewModels()

    private var speechManager: SpeechRecognitionManager? = null
    private var ttsManager: TextToSpeechManager? = null

    /** The command we were trying to run when we discovered we needed a permission. */
    private var pendingRetryCommand: String? = null
    private var pendingRationale: String? = null

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val command = pendingRetryCommand
        val rationale = pendingRationale
        pendingRetryCommand = null
        pendingRationale = null
        if (granted && command != null) {
            viewModel.retryAfterPermissionGranted(command)
        } else if (!granted && rationale != null) {
            viewModel.onPermissionDenied(rationale)
        }
    }

    private val requestMicPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startVoiceListening()
        } else {
            Toast.makeText(this, getString(R.string.perm_mic_rationale), Toast.LENGTH_LONG).show()
        }
    }

    private val requestNotificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* result not critical to app function; reminders simply won't show if denied */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        ttsManager = TextToSpeechManager(applicationContext)

        // Ask for notification permission up front on Android 13+ since reminders need it
        // and there's no natural "first use" moment before the user sets one.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (androidx.core.content.ContextCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS
                ) != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        setContent {
            var screen by remember { mutableStateOf(Screen.CHAT) }

            val messages by viewModel.messages.collectAsState()
            val isLoading by viewModel.isLoading.collectAsState()
            val isListening by viewModel.isListening.collectAsState()
            val ttsEnabled by viewModel.ttsEnabled.collectAsState()
            val darkTheme by viewModel.darkTheme.collectAsState()
            val backendUrl by viewModel.backendUrlFlow.collectAsState()
            val apiKey by viewModel.apiKeyFlow.collectAsState()

            LaunchedEffect(ttsEnabled) {
                ttsManager?.enabled = ttsEnabled
            }

            LaunchedEffect(Unit) {
                viewModel.events.collectLatest { event ->
                    when (event) {
                        is UiEvent.RequestPermission -> {
                            pendingRetryCommand = event.retryCommand
                            pendingRationale = event.rationale
                            Toast.makeText(this@MainActivity, event.rationale, Toast.LENGTH_SHORT).show()
                            requestPermissionLauncher.launch(event.permission)
                        }
                        is UiEvent.RequestExactAlarmSettings -> {
                            openExactAlarmSettings()
                        }
                        is UiEvent.Speak -> {
                            ttsManager?.speak(event.text)
                        }
                    }
                }
            }

            AjeboTheme(darkTheme = darkTheme) {
                when (screen) {
                    Screen.CHAT -> ChatScreen(
                        messages = messages,
                        isLoading = isLoading,
                        isListening = isListening,
                        isDarkTheme = darkTheme,
                        micAvailable = true,
                        onSend = { text -> viewModel.onUserSubmit(text) },
                        onMicClick = { onMicButtonClicked() },
                        onClearChat = { viewModel.clearChat() },
                        onOpenSettings = { screen = Screen.SETTINGS }
                    )
                    Screen.SETTINGS -> SettingsScreen(
                        ttsEnabled = ttsEnabled,
                        darkTheme = darkTheme,
                        backendUrl = backendUrl,
                        apiKeyOverride = apiKey,
                        onTtsToggle = { viewModel.setTtsEnabled(it) },
                        onDarkThemeToggle = { viewModel.setDarkTheme(it) },
                        onSaveBackendUrl = { viewModel.saveBackendUrl(it) },
                        onSaveApiKey = { viewModel.saveApiKeyOverride(it) },
                        onClearChat = { viewModel.clearChat() },
                        onBack = { screen = Screen.CHAT }
                    )
                }
            }
        }
    }

    // -----------------------------------------------------------------
    // Voice input
    // -----------------------------------------------------------------

    private fun onMicButtonClicked() {
        if (viewModel.isListening.value) {
            speechManager?.stopListening()
            return
        }

        val hasMicPermission = androidx.core.content.ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

        if (hasMicPermission) {
            startVoiceListening()
        } else {
            requestMicPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startVoiceListening() {
        speechManager?.destroy()
        speechManager = SpeechRecognitionManager(
            context = applicationContext,
            onResult = { recognizedText ->
                viewModel.setListening(false)
                viewModel.onUserSubmit(recognizedText)
            },
            onListeningStateChanged = { listening -> viewModel.setListening(listening) },
            onError = { errorMessage ->
                viewModel.setListening(false)
                Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
            }
        )
        if (speechManager?.isAvailable() == true) {
            speechManager?.startListening()
        } else {
            Toast.makeText(this, "Speech recognition isn't available on this device.", Toast.LENGTH_LONG).show()
        }
    }

    // -----------------------------------------------------------------
    // Exact-alarm special access (Android 12+)
    // -----------------------------------------------------------------

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(
                    this,
                    "Please enable \"Alarms & reminders\" for Ajebo in system Settings.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onDestroy() {
        speechManager?.destroy()
        ttsManager?.shutdown()
        super.onDestroy()
    }
}
