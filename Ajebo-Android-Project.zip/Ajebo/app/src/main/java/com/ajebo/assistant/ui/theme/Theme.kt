package com.ajebo.assistant.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = AjeboPurple,
    onPrimary = AjeboOnPurple,
    secondary = AjeboTeal,
    background = AjeboBgLight,
    surface = AjeboSurfaceLight,
    error = AjeboError
)

private val DarkColors = darkColorScheme(
    primary = AjeboPurple,
    onPrimary = AjeboOnPurple,
    secondary = AjeboTeal,
    background = AjeboBgDark,
    surface = AjeboSurfaceDark,
    error = AjeboError
)

/**
 * Deliberately skips Compose's "dynamic color" (Material You) path: it pulls in extra
 * wallpaper-sampling work that isn't worth it on a 2GB-RAM device, and a fixed brand
 * palette keeps Ajebo looking consistent everywhere.
 */
@Composable
fun AjeboTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colorScheme,
        typography = AjeboTypography,
        content = content
    )
}
