package com.ajebo.assistant.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.ajebo.assistant.data.Message
import com.ajebo.assistant.data.Sender
import com.ajebo.assistant.ui.theme.AjeboBubbleAiDark
import com.ajebo.assistant.ui.theme.AjeboBubbleAiLight
import com.ajebo.assistant.ui.theme.AjeboBubbleUserDark
import com.ajebo.assistant.ui.theme.AjeboBubbleUserLight
import com.ajebo.assistant.ui.theme.AjeboError

@Composable
fun MessageBubble(message: Message, isDarkTheme: Boolean) {
    val isUser = message.sender == Sender.USER
    val alignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart

    val backgroundColor: Color = when {
        message.isError -> AjeboError.copy(alpha = 0.12f)
        isUser -> if (isDarkTheme) AjeboBubbleUserDark else AjeboBubbleUserLight
        else -> if (isDarkTheme) AjeboBubbleAiDark else AjeboBubbleAiLight
    }

    val textColor: Color = when {
        message.isError -> AjeboError
        isUser -> Color.White
        else -> MaterialTheme.colorScheme.onSurface
    }

    val shape = if (isUser) {
        RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 4.dp)
    } else {
        RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 4.dp, bottomEnd = 18.dp)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
        contentAlignment = alignment
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 300.dp)
                .background(backgroundColor, shape)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(
                text = message.text,
                color = textColor,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = if (isUser) TextAlign.End else TextAlign.Start
            )
        }
    }
}
