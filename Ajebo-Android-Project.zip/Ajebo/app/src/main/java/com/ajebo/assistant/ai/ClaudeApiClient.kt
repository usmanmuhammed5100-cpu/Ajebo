package com.ajebo.assistant.ai

import com.ajebo.assistant.data.Message
import com.ajebo.assistant.data.Sender
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed class ClaudeResult {
    data class Success(val reply: String) : ClaudeResult()
    data class Failure(val message: String) : ClaudeResult()
}

/**
 * Thin, dependency-light client for talking to Claude — either through a secure
 * backend proxy (recommended) or directly against the Anthropic API for local
 * development. See ApiConfig for how the target is chosen.
 */
class ClaudeApiClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun sendMessage(
        history: List<Message>,
        userText: String,
        config: ResolvedApiConfig
    ): ClaudeResult = withContext(Dispatchers.IO) {
        if (config.mode == ResolvedApiConfig.Mode.UNCONFIGURED) {
            return@withContext ClaudeResult.Failure(
                "Ajebo isn't connected to an AI backend yet. Open Settings → AI/API Settings " +
                    "and either enter your backend proxy URL or a development API key."
            )
        }

        try {
            val requestBody = when (config.mode) {
                ResolvedApiConfig.Mode.BACKEND_PROXY -> buildProxyPayload(history, userText)
                ResolvedApiConfig.Mode.DIRECT_DEV_KEY -> buildDirectAnthropicPayload(history, userText)
                ResolvedApiConfig.Mode.UNCONFIGURED -> return@withContext ClaudeResult.Failure("Unconfigured")
            }

            val requestBuilder = Request.Builder()
                .url(config.endpoint)
                .post(requestBody.toString().toRequestBody(jsonMediaType))

            when (config.mode) {
                ResolvedApiConfig.Mode.DIRECT_DEV_KEY -> {
                    requestBuilder
                        .addHeader("x-api-key", config.apiKey)
                        .addHeader("anthropic-version", "2023-06-01")
                        .addHeader("content-type", "application/json")
                }
                ResolvedApiConfig.Mode.BACKEND_PROXY -> {
                    requestBuilder.addHeader("content-type", "application/json")
                }
                else -> {}
            }

            client.newCall(requestBuilder.build()).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext ClaudeResult.Failure(
                        "AI request failed (HTTP ${response.code}). ${extractErrorMessage(bodyString)}"
                    )
                }
                val reply = when (config.mode) {
                    ResolvedApiConfig.Mode.DIRECT_DEV_KEY -> parseAnthropicReply(bodyString)
                    ResolvedApiConfig.Mode.BACKEND_PROXY -> parseProxyReply(bodyString)
                    else -> null
                }
                if (reply.isNullOrBlank()) {
                    ClaudeResult.Failure("Ajebo received an empty response. Please try again.")
                } else {
                    ClaudeResult.Success(reply)
                }
            }
        } catch (e: IOException) {
            ClaudeResult.Failure("Network error talking to Ajebo's AI service: ${e.message ?: "unknown error"}")
        } catch (e: Exception) {
            ClaudeResult.Failure("Unexpected error: ${e.message ?: "unknown error"}")
        }
    }

    /** Anthropic /v1/messages format, sent directly (dev-only path). */
    private fun buildDirectAnthropicPayload(history: List<Message>, userText: String): JSONObject {
        val messages = JSONArray()
        history.filter { it.sender != Sender.SYSTEM }.forEach { msg ->
            messages.put(
                JSONObject().apply {
                    put("role", if (msg.sender == Sender.USER) "user" else "assistant")
                    put("content", msg.text)
                }
            )
        }
        messages.put(JSONObject().apply {
            put("role", "user")
            put("content", userText)
        })

        return JSONObject().apply {
            put("model", ApiConfig.CLAUDE_MODEL)
            put("max_tokens", 1024)
            put("system", ASSISTANT_SYSTEM_PROMPT)
            put("messages", messages)
        }
    }

    /** Simple payload for our own backend proxy — the proxy adds the real API key. */
    private fun buildProxyPayload(history: List<Message>, userText: String): JSONObject {
        val messages = JSONArray()
        history.filter { it.sender != Sender.SYSTEM }.takeLast(20).forEach { msg ->
            messages.put(
                JSONObject().apply {
                    put("role", if (msg.sender == Sender.USER) "user" else "assistant")
                    put("content", msg.text)
                }
            )
        }
        messages.put(JSONObject().apply {
            put("role", "user")
            put("content", userText)
        })
        return JSONObject().apply {
            put("messages", messages)
        }
    }

    private fun parseAnthropicReply(body: String): String? {
        return try {
            val json = JSONObject(body)
            val content = json.optJSONArray("content") ?: return null
            val sb = StringBuilder()
            for (i in 0 until content.length()) {
                val block = content.getJSONObject(i)
                if (block.optString("type") == "text") {
                    sb.append(block.optString("text"))
                }
            }
            val text = sb.toString()
            if (text.isBlank()) null else text
        } catch (e: Exception) {
            null
        }
    }

    private fun parseProxyReply(body: String): String? {
        return try {
            val json = JSONObject(body)
            val reply = json.optString("reply")
            if (reply.isBlank()) null else reply
        } catch (e: Exception) {
            null
        }
    }

    private fun extractErrorMessage(body: String): String {
        return try {
            val json = JSONObject(body)
            val nestedMessage = json.optJSONObject("error")?.optString("message").orEmpty()
            if (nestedMessage.isNotBlank()) return nestedMessage

            val topLevelMessage = json.optString("message")
            if (topLevelMessage.isNotBlank()) return topLevelMessage

            "Please check your API configuration in Settings."
        } catch (e: Exception) {
            "Please check your API configuration in Settings."
        }
    }

    companion object {
        const val ASSISTANT_SYSTEM_PROMPT =
            "You are Ajebo, a friendly, concise personal AI assistant living inside an Android app. " +
                "Keep replies short and conversational, suitable for a phone chat bubble. " +
                "If the user asks you to perform a phone action (calling, texting, opening an app, " +
                "setting an alarm, etc.), note that the app's action handler manages those directly; " +
                "just respond naturally."
    }
}
