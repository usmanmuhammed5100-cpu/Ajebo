package com.ajebo.assistant.ai

import com.ajebo.assistant.BuildConfig

/**
 * Central place that decides how Ajebo will reach the Claude API.
 *
 * Ajebo NEVER contains a hard-coded secret key in source. There are exactly two
 * supported ways to configure access, in priority order:
 *
 * 1. BACKEND PROXY (recommended, secure) — Ajebo calls your own small backend
 *    (see /backend in the project root) which holds the real Anthropic API key
 *    server-side and forwards the chat request. The app only ever knows the
 *    backend's URL, which is not a secret.
 *
 * 2. DIRECT DEV KEY (local testing only, NOT secure for distribution) — a key
 *    can be supplied at build time via local.properties -> BuildConfig, or typed
 *    into Settings at runtime and held only in DataStore on-device. Either way
 *    this means the key lives on the device, which is fine for your own dev
 *    phone but unsafe for any APK you hand to someone else, since it can be
 *    extracted by decompiling the app or inspecting its storage.
 */
data class ResolvedApiConfig(
    val mode: Mode,
    val endpoint: String,
    val apiKey: String
) {
    enum class Mode { BACKEND_PROXY, DIRECT_DEV_KEY, UNCONFIGURED }
}

object ApiConfig {

    private const val ANTHROPIC_DIRECT_ENDPOINT = "https://api.anthropic.com/v1/messages"
    const val CLAUDE_MODEL = "claude-sonnet-4-6"

    /**
     * @param settingsBackendUrl backend URL saved by the user in Settings (may be blank)
     * @param settingsApiKey dev-only key saved by the user in Settings (may be blank)
     */
    fun resolve(settingsBackendUrl: String, settingsApiKey: String): ResolvedApiConfig {
        val backendUrl = settingsBackendUrl.ifBlank { BuildConfig.AJEBO_BACKEND_URL }
        if (backendUrl.isNotBlank()) {
            return ResolvedApiConfig(ResolvedApiConfig.Mode.BACKEND_PROXY, backendUrl, "")
        }

        val devKey = settingsApiKey.ifBlank { BuildConfig.CLAUDE_API_KEY }
        if (devKey.isNotBlank()) {
            return ResolvedApiConfig(ResolvedApiConfig.Mode.DIRECT_DEV_KEY, ANTHROPIC_DIRECT_ENDPOINT, devKey)
        }

        return ResolvedApiConfig(ResolvedApiConfig.Mode.UNCONFIGURED, "", "")
    }
}
