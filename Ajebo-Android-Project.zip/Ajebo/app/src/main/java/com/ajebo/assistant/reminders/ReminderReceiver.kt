package com.ajebo.assistant.reminders

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.ajebo.assistant.AjeboApplication
import com.ajebo.assistant.MainActivity
import com.ajebo.assistant.R

/**
 * Receives the AlarmManager broadcast at the exact moment a reminder is due and shows
 * a real Android notification. This is the actual mechanism behind commands like
 * "Remind me to study at 6 PM" — it does not simulate anything.
 */
class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val text = intent.getStringExtra(EXTRA_TEXT) ?: "Reminder"
        val id = intent.getIntExtra(EXTRA_ID, 0)

        // Notification permission (Android 13+) may have been revoked since the reminder
        // was scheduled. We check before posting rather than assuming success.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) {
                return
            }
        }

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context, id, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, AjeboApplication.REMINDER_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Ajebo reminder")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(contentPendingIntent)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        try {
            manager.notify(id, notification)
        } catch (e: SecurityException) {
            // Notification permission was revoked between the check above and this call;
            // there is nothing more we can do for this one-off reminder firing.
        }

        // Reminder has fired; stop tracking it so BootReceiver won't re-arm a past alarm.
        ReminderScheduler(context.applicationContext).clearPersisted(id)
    }

    companion object {
        const val EXTRA_TEXT = "extra_text"
        const val EXTRA_ID = "extra_id"
    }
}
