package com.ajebo.assistant.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ajebo.assistant.actions.ActionOutcome
import com.ajebo.assistant.actions.PhoneActionHandler
import com.ajebo.assistant.ai.ApiConfig
import com.ajebo.assistant.ai.ClaudeApiClient
import com.ajebo.assistant.ai.ClaudeResult
import com.ajebo.assistant.reminders.ReminderScheduler
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** One-off events the UI (Activity/Compose) must react to, e.g. requesting a permission. */
sealed class UiEvent {
    data class RequestPermission(val permission: String, val rationale: String, val retryCommand: String) : UiEvent()
    data class RequestExactAlarmSettings(val retryCommand: String) : UiEvent()
    data class Speak(val text: String) : UiEvent()
}

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsRepository = SettingsRepository(application)
    private val claudeApiClient = ClaudeApiClient()
    private val reminderScheduler = ReminderScheduler(application)
    private val phoneActionHandler = PhoneActionHandler(application, reminderScheduler)

    private val _messages = MutableStateFlow<List<Message>>(
        listOf(
            Message(
                text = "Hi, I'm Ajebo 👋 Ask me anything, or tell me to do something on your phone — " +
                    "like \"call Mom\", \"open YouTube\", or \"remind me to study at 6 PM\".",
                sender = Sender.AJEBO
            )
        )
    )
    val messages: StateFlow<List<Message>> = _messages.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    val ttsEnabled: StateFlow<Boolean> get() = ttsEnabledState
    private val ttsEnabledState = MutableStateFlow(true)

    val darkTheme: StateFlow<Boolean> get() = darkThemeState
    private val darkThemeState = MutableStateFlow(false)

    val backendUrlFlow: StateFlow<String> get() = backendUrlState
    private val backendUrlState = MutableStateFlow("")

    val apiKeyFlow: StateFlow<String> get() = apiKeyState
    private val apiKeyState = MutableStateFlow("")

    private val _events = MutableSharedFlow<UiEvent>(extraBufferCapacity = 4)
    val events: SharedFlow<UiEvent> = _events.asSharedFlow()

    init {
        viewModelScope.launch {
            settingsRepository.ttsEnabled.collect { ttsEnabledState.value = it }
        }
        viewModelScope.launch {
            settingsRepository.darkTheme.collect { darkThemeState.value = it }
        }
        viewModelScope.launch {
            settingsRepository.backendUrl.collect { backendUrlState.value = it }
        }
        viewModelScope.launch {
            settingsRepository.apiKeyOverride.collect { apiKeyState.value = it }
        }
    }

    fun setListening(listening: Boolean) {
        _isListening.value = listening
    }

    fun setTtsEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setTtsEnabled(enabled) }
    }

    fun setDarkTheme(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setDarkTheme(enabled) }
    }

    fun clearChat() {
        _messages.value = emptyList()
    }

    suspend fun currentSettingsSnapshot(): Pair<String, String> {
        val url = settingsRepository.backendUrl.first()
        val key = settingsRepository.apiKeyOverride.first()
        return url to key
    }

    fun saveBackendUrl(url: String) {
        viewModelScope.launch { settingsRepository.setBackendUrl(url) }
    }

    fun saveApiKeyOverride(key: String) {
        viewModelScope.launch { settingsRepository.setApiKeyOverride(key) }
    }

    /**
     * Entry point called from the UI whenever the user sends text — either typed or the
     * result of speech recognition. First tries to interpret it as a real device command;
     * only if it's not recognized does it fall back to a normal AI conversation turn.
     */
    fun onUserSubmit(text: String) {
        val trimmed = text.trim()
        if (trimmed.isBlank()) return

        addMessage(Message(text = trimmed, sender = Sender.USER))

        when (val outcome = phoneActionHandler.handle(trimmed)) {
            is ActionOutcome.Success -> {
                addMessage(Message(text = outcome.message, sender = Sender.SYSTEM))
                maybeSpeak(outcome.message)
            }
            is ActionOutcome.Failure -> {
                addMessage(Message(text = outcome.message, sender = Sender.SYSTEM, isError = true))
                maybeSpeak(outcome.message)
            }
            is ActionOutcome.NeedsPermission -> {
                _events.tryEmit(UiEvent.RequestPermission(outcome.permission, outcome.rationale, outcome.retryCommand))
            }
            is ActionOutcome.NeedsExactAlarmSettings -> {
                addMessage(
                    Message(
                        text = "I need \"Alarms & reminders\" permission to schedule this. Opening Settings…",
                        sender = Sender.SYSTEM
                    )
                )
                _events.tryEmit(UiEvent.RequestExactAlarmSettings(outcome.retryCommand))
            }
            ActionOutcome.NotRecognized -> sendToAi(trimmed)
        }
    }

    /** Called by the UI after a previously-missing permission has just been granted. */
    fun retryAfterPermissionGranted(command: String) {
        when (val outcome = phoneActionHandler.handle(command)) {
            is ActionOutcome.Success -> {
                addMessage(Message(text = outcome.message, sender = Sender.SYSTEM))
                maybeSpeak(outcome.message)
            }
            is ActionOutcome.Failure -> {
                addMessage(Message(text = outcome.message, sender = Sender.SYSTEM, isError = true))
            }
            is ActionOutcome.NeedsPermission -> {
                addMessage(
                    Message(
                        text = "I still need permission to do that. You can grant it from Settings → Permissions.",
                        sender = Sender.SYSTEM,
                        isError = true
                    )
                )
            }
            is ActionOutcome.NeedsExactAlarmSettings -> {
                _events.tryEmit(UiEvent.RequestExactAlarmSettings(outcome.retryCommand))
            }
            ActionOutcome.NotRecognized -> Unit
        }
    }

    fun onPermissionDenied(rationale: String) {
        addMessage(
            Message(
                text = "$rationale Without it I can't complete that action.",
                sender = Sender.SYSTEM,
                isError = true
            )
        )
    }

    private fun sendToAi(userText: String) {
        _isLoading.value = true
        viewModelScope.launch {
            try {
                val (backendUrl, apiKey) = currentSettingsSnapshot()
                val config = ApiConfig.resolve(backendUrl, apiKey)
                val historySnapshot = _messages.value

                when (val result = claudeApiClient.sendMessage(historySnapshot, userText, config)) {
                    is ClaudeResult.Success -> {
                        addMessage(Message(text = result.reply, sender = Sender.AJEBO))
                        maybeSpeak(result.reply)
                    }
                    is ClaudeResult.Failure -> {
                        addMessage(Message(text = result.message, sender = Sender.SYSTEM, isError = true))
                    }
                }
            } catch (e: Exception) {
                addMessage(
                    Message(
                        text = "Something went wrong reaching Ajebo's AI service: ${e.message ?: "unknown error"}",
                        sender = Sender.SYSTEM,
                        isError = true
                    )
                )
            } finally {
                _isLoading.value = false
            }
        }
    }

    private fun maybeSpeak(text: String) {
        if (ttsEnabledState.value) {
            _events.tryEmit(UiEvent.Speak(text))
        }
    }

    private fun addMessage(message: Message) {
        _messages.value = _messages.value + message
    }
}
