package com.ajebo.assistant.reminders

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONObject

private val Context.reminderStore by preferencesDataStore(name = "ajebo_reminders")

data class ScheduledReminder(
    val id: Int,
    val text: String,
    val triggerAtMillis: Long
)

sealed class ScheduleResult {
    data class Scheduled(val reminder: ScheduledReminder) : ScheduleResult()
    object MissingExactAlarmPermission : ScheduleResult()
    data class Failed(val reason: String) : ScheduleResult()
}

/**
 * Creates real OS-level alarms for reminders using AlarmManager.setExactAndAllowWhileIdle,
 * the modern, correct way to fire a one-off notification at a precise wall-clock time on
 * Android. Reminders are also persisted to DataStore so BootReceiver can re-arm them after
 * a device restart (alarms do not survive a reboot on their own).
 */
class ReminderScheduler(private val context: Context) {

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    private val storeKey = stringSetPreferencesKey("pending_reminders")
    private val ioScope = CoroutineScope(Dispatchers.IO)

    fun canScheduleExactAlarms(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }
    }

    /**
     * Schedules a reminder. Returns MissingExactAlarmPermission on Android 12+ if the user
     * has not granted "Alarms & reminders" access — the caller should direct them to that
     * system settings screen; there is no runtime permission dialog for it.
     */
    fun schedule(text: String, triggerAtMillis: Long): ScheduleResult {
        if (!canScheduleExactAlarms()) {
            return ScheduleResult.MissingExactAlarmPermission
        }
        val id = (triggerAtMillis.hashCode() xor text.hashCode()) and 0x7FFFFFFF

        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra(ReminderReceiver.EXTRA_TEXT, text)
            putExtra(ReminderReceiver.EXTRA_ID, id)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return try {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerAtMillis,
                pendingIntent
            )
            val reminder = ScheduledReminder(id, text, triggerAtMillis)
            persist(reminder)
            ScheduleResult.Scheduled(reminder)
        } catch (e: SecurityException) {
            ScheduleResult.MissingExactAlarmPermission
        } catch (e: Exception) {
            ScheduleResult.Failed(e.message ?: "Unknown error scheduling reminder")
        }
    }

    fun cancel(id: Int) {
        val intent = Intent(context, ReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context, id, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }

    private fun persist(reminder: ScheduledReminder) {
        // Fire-and-forget persistence so the reminder can be re-armed by BootReceiver.
        ioScope.launch {
            val json = JSONObject().apply {
                put("id", reminder.id)
                put("text", reminder.text)
                put("time", reminder.triggerAtMillis)
            }.toString()

            context.reminderStore.edit { prefs ->
                val current = prefs[storeKey]?.toMutableSet() ?: mutableSetOf()
                current.add(json)
                prefs[storeKey] = current
            }
        }
    }

    /** Removes a persisted reminder once it has fired, so it isn't re-armed on next boot. */
    fun clearPersisted(id: Int) {
        ioScope.launch {
            context.reminderStore.edit { prefs ->
                val current = prefs[storeKey]?.toMutableSet() ?: mutableSetOf()
                current.removeAll { entry ->
                    try { JSONObject(entry).getInt("id") == id } catch (e: Exception) { false }
                }
                prefs[storeKey] = current
            }
        }
    }

    suspend fun getAllPersisted(): List<ScheduledReminder> {
        val prefs = context.reminderStore.data.first()
        val raw = prefs[storeKey] ?: emptySet()
        return raw.mapNotNull {
            try {
                val json = JSONObject(it)
                ScheduledReminder(
                    id = json.getInt("id"),
                    text = json.getString("text"),
                    triggerAtMillis = json.getLong("time")
                )
            } catch (e: Exception) {
                null
            }
        }
    }
}
