package com.ajebo.assistant.actions

import android.Manifest
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.ajebo.assistant.reminders.ReminderScheduler
import com.ajebo.assistant.reminders.ScheduleResult
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.regex.Pattern

/**
 * Result of trying to handle a command as a device action rather than an AI chat message.
 */
sealed class ActionOutcome {
    /** The action genuinely happened; Android confirmed it. */
    data class Success(val message: String) : ActionOutcome()

    /** We recognized the command but could not complete it (app missing, bad input, etc.). */
    data class Failure(val message: String) : ActionOutcome()

    /** A dangerous permission is required first. UI should request it, then retry the same text. */
    data class NeedsPermission(
        val permission: String,
        val rationale: String,
        val retryCommand: String
    ) : ActionOutcome()

    /** Android 12+ "Alarms & reminders" special access is missing; must be granted in Settings. */
    data class NeedsExactAlarmSettings(val retryCommand: String) : ActionOutcome()

    /** Not a device command at all — hand off to the AI for normal conversation. */
    object NotRecognized : ActionOutcome()
}

/**
 * Recognizes a fixed set of phone-control commands and performs them using real Android
 * Intents/APIs. Nothing here is simulated: every Success outcome corresponds to Android
 * actually having launched an activity, placed a broadcast, or scheduled a system alarm.
 */
class PhoneActionHandler(
    private val context: Context,
    private val reminderScheduler: ReminderScheduler
) {

    fun handle(rawCommand: String): ActionOutcome {
        val command = rawCommand.trim()
        val lower = command.lowercase(Locale.getDefault())

        return when {
            lower.matches(Regex(".*\\b(what('?s)?|tell me) the (time|date).*")) ||
                lower == "time" || lower == "date" -> tellTimeOrDate(lower)

            lower.startsWith("call ") -> callContact(command.substring(5).trim())

            lower.startsWith("send a message") || lower.startsWith("send message") ||
                lower.startsWith("text ") || lower.startsWith("message ") -> sendMessage(command)

            lower.contains("open whatsapp") -> openApp("com.whatsapp", "WhatsApp")

            lower.contains("open youtube") -> openApp("com.google.android.youtube", "YouTube", webFallback = "https://youtube.com")

            lower.contains("open chrome") -> openApp("com.android.chrome", "Chrome", webFallback = "https://google.com")

            lower.contains("open settings") -> openSettings()

            lower.contains("open maps") || lower.startsWith("navigate to") || lower.startsWith("directions to") ->
                openMaps(command)

            lower.startsWith("set an alarm") || lower.startsWith("set alarm") -> setAlarm(command)

            lower.startsWith("remind me") -> createReminder(command)

            lower.startsWith("search for") || lower.startsWith("search the web") || lower.startsWith("google ") ->
                searchWeb(command)

            lower.startsWith("play ") -> playMusic(command)

            lower.contains("show contacts") || lower == "contacts" || lower == "show my contacts" ->
                showContacts()

            lower.startsWith("open ") -> openArbitraryApp(command.substring(5).trim())

            else -> ActionOutcome.NotRecognized
        }
    }

    // ---------------------------------------------------------------------
    // Time / date
    // ---------------------------------------------------------------------

    private fun tellTimeOrDate(lower: String): ActionOutcome {
        val now = Calendar.getInstance()
        return if (lower.contains("date")) {
            val fmt = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault())
            ActionOutcome.Success("Today is ${fmt.format(now.time)}.")
        } else {
            val fmt = SimpleDateFormat("h:mm a", Locale.getDefault())
            ActionOutcome.Success("It's currently ${fmt.format(now.time)}.")
        }
    }

    // ---------------------------------------------------------------------
    // Calling
    // ---------------------------------------------------------------------

    private fun callContact(rawName: String): ActionOutcome {
        val name = rawName.trim().trimEnd('.', '!', '?')
        if (name.isBlank()) {
            return ActionOutcome.Failure("Tell me who to call, e.g. \"Call Mom\".")
        }

        if (!hasPermission(Manifest.permission.READ_CONTACTS)) {
            return ActionOutcome.NeedsPermission(
                Manifest.permission.READ_CONTACTS,
                "Ajebo needs contacts access to find ${name}'s phone number.",
                "call $name"
            )
        }

        val phoneNumber = lookupPhoneNumber(name)
            ?: return ActionOutcome.Failure("I couldn't find a contact named \"$name\".")

        if (!hasPermission(Manifest.permission.CALL_PHONE)) {
            return ActionOutcome.NeedsPermission(
                Manifest.permission.CALL_PHONE,
                "Ajebo needs phone permission to place the call to $name.",
                "call $name"
            )
        }

        return try {
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$phoneNumber")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionOutcome.Success("Calling $name…")
        } catch (e: SecurityException) {
            ActionOutcome.Failure("Android blocked the call: ${e.message}")
        } catch (e: Exception) {
            ActionOutcome.Failure("Couldn't start the call: ${e.message}")
        }
    }

    private fun lookupPhoneNumber(name: String): String? {
        val resolver = context.contentResolver
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%$name%")

        resolver.query(uri, projection, selection, selectionArgs, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val numberIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                if (numberIndex >= 0) return cursor.getString(numberIndex)
            }
        }
        return null
    }

    // ---------------------------------------------------------------------
    // Messaging — uses ACTION_SENDTO so the user's own default SMS/chat app
    // sends the message; Ajebo never sends SMS silently on its own.
    // ---------------------------------------------------------------------

    private fun sendMessage(command: String): ActionOutcome {
        // Try to pull "text John hello there" / "send message to John: hello there"
        val toMatch = Pattern.compile(
            "(?:text|message)\\s+([a-zA-Z ]+?)(?:\\s+(?:saying|that|:)\\s+(.*))?$",
            Pattern.CASE_INSENSITIVE
        ).matcher(command)

        var recipient = ""
        var body = ""
        if (toMatch.find()) {
            recipient = toMatch.group(1)?.trim().orEmpty()
            body = toMatch.group(2)?.trim().orEmpty()
        }

        var number: String? = null
        if (recipient.isNotBlank()) {
            if (hasPermission(Manifest.permission.READ_CONTACTS)) {
                number = lookupPhoneNumber(recipient)
            }
        }

        val uri = if (number != null) Uri.parse("smsto:$number") else Uri.parse("smsto:")
        return try {
            val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
                if (body.isNotBlank()) putExtra("sms_body", body)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionOutcome.Success(
                if (number != null) "Opening your messaging app to text $recipient…"
                else "Opening your messaging app…"
            )
        } catch (e: ActivityNotFoundException) {
            ActionOutcome.Failure("No messaging app is available to handle this.")
        }
    }

    // ---------------------------------------------------------------------
    // Opening apps
    // ---------------------------------------------------------------------

    private fun openApp(packageName: String, friendlyName: String, webFallback: String? = null): ActionOutcome {
        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(packageName)
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            ActionOutcome.Success("Opening $friendlyName…")
        } else if (webFallback != null) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(webFallback)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                ActionOutcome.Success("$friendlyName isn't installed, so I opened it in your browser instead.")
            } catch (e: ActivityNotFoundException) {
                ActionOutcome.Failure("$friendlyName isn't installed and no browser is available either.")
            }
        } else {
            ActionOutcome.Failure("$friendlyName doesn't seem to be installed on this device.")
        }
    }

    private fun openArbitraryApp(appNameRaw: String): ActionOutcome {
        val appName = appNameRaw.trim().trimEnd('.', '!', '?')
        if (appName.isBlank()) return ActionOutcome.NotRecognized

        val pm = context.packageManager
        val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val match = installedApps.firstOrNull {
            pm.getApplicationLabel(it).toString().contains(appName, ignoreCase = true)
        }

        return if (match != null) {
            val launchIntent = pm.getLaunchIntentForPackage(match.packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                ActionOutcome.Success("Opening ${pm.getApplicationLabel(match)}…")
            } else {
                ActionOutcome.Failure("Found \"$appName\" but it can't be launched directly.")
            }
        } else {
            ActionOutcome.Failure("I couldn't find an app called \"$appName\" on this device.")
        }
    }

    private fun openSettings(): ActionOutcome {
        return try {
            val intent = Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            ActionOutcome.Success("Opening Settings…")
        } catch (e: ActivityNotFoundException) {
            ActionOutcome.Failure("Couldn't open Settings on this device.")
        }
    }

    private fun openMaps(command: String): ActionOutcome {
        val query = command
            .replace(Regex("(?i)open maps( to)?"), "")
            .replace(Regex("(?i)navigate to"), "")
            .replace(Regex("(?i)directions to"), "")
            .trim()

        val uri = if (query.isBlank()) {
            Uri.parse("geo:0,0?q=") // just opens the Maps app
        } else {
            Uri.parse("geo:0,0?q=" + Uri.encode(query))
        }

        return try {
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage("com.google.android.apps.maps")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionOutcome.Success(if (query.isBlank()) "Opening Maps…" else "Opening Maps for \"$query\"…")
        } catch (e: ActivityNotFoundException) {
            // Google Maps app not installed — fall back to any app that can view a geo: URI.
            try {
                val fallback = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(fallback)
                ActionOutcome.Success("Opening a maps app for \"$query\"…")
            } catch (e2: ActivityNotFoundException) {
                ActionOutcome.Failure("No maps app is installed on this device.")
            }
        }
    }

    private fun showContacts(): ActionOutcome {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            ActionOutcome.Success("Opening your contacts…")
        } catch (e: ActivityNotFoundException) {
            ActionOutcome.Failure("No contacts app is available on this device.")
        }
    }

    // ---------------------------------------------------------------------
    // Music
    // ---------------------------------------------------------------------

    private fun playMusic(command: String): ActionOutcome {
        val query = command.replaceFirst(Regex("(?i)^play\\s+"), "").trim()

        // Prefer a dedicated music app if one is installed.
        val musicPackages = listOf("com.spotify.music", "com.google.android.apps.youtube.music")
        for (pkg in musicPackages) {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return ActionOutcome.Success(
                    if (query.isBlank()) "Opening your music app…"
                    else "Opening your music app — search for \"$query\" there."
                )
            }
        }

        return try {
            val intent = Intent(MediaStore.INTENT_ACTION_MUSIC_PLAYER).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            ActionOutcome.Success("Opening your music player…")
        } catch (e: ActivityNotFoundException) {
            ActionOutcome.Failure("No music app is installed on this device.")
        }
    }

    // ---------------------------------------------------------------------
    // Web search
    // ---------------------------------------------------------------------

    private fun searchWeb(command: String): ActionOutcome {
        val query = command
            .replaceFirst(Regex("(?i)^search for\\s+"), "")
            .replaceFirst(Regex("(?i)^search the web for\\s+"), "")
            .replaceFirst(Regex("(?i)^search the web\\s+"), "")
            .replaceFirst(Regex("(?i)^google\\s+"), "")
            .trim()

        if (query.isBlank()) return ActionOutcome.Failure("What would you like me to search for?")

        return try {
            val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra(SearchManager.QUERY, query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionOutcome.Success("Searching the web for \"$query\"…")
        } catch (e: ActivityNotFoundException) {
            try {
                val fallback = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
                ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(fallback)
                ActionOutcome.Success("Searching the web for \"$query\"…")
            } catch (e2: ActivityNotFoundException) {
                ActionOutcome.Failure("No browser is available to search the web.")
            }
        }
    }

    // ---------------------------------------------------------------------
    // Alarms — uses AlarmClock intent, which hands off to the phone's own
    // Clock app. This is the correct, user-consented way for a third-party
    // app to create a ringing alarm on Android.
    // ---------------------------------------------------------------------

    private fun setAlarm(command: String): ActionOutcome {
        val time = TimeParser.extractClockTime(command)
            ?: return ActionOutcome.Failure(
                "Tell me a time, e.g. \"Set an alarm for 6:30 AM\"."
            )

        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, time.first)
                putExtra(AlarmClock.EXTRA_MINUTES, time.second)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            val fmt = String.format(Locale.getDefault(), "%d:%02d", to12Hour(time.first), time.second)
            ActionOutcome.Success("Opening your Clock app to confirm the alarm for $fmt.")
        } catch (e: ActivityNotFoundException) {
            ActionOutcome.Failure("No Clock app is available to set an alarm on this device.")
        }
    }

    private fun to12Hour(hour24: Int): Int {
        val h = hour24 % 12
        return if (h == 0) 12 else h
    }

    // ---------------------------------------------------------------------
    // Reminders — a real AlarmManager alarm + notification, not a Clock-app
    // hand-off, so Ajebo controls the exact text shown when it fires.
    // ---------------------------------------------------------------------

    private fun createReminder(command: String): ActionOutcome {
        // "remind me to <task> at <time>" / "remind me to <task> in <duration>"
        val body = command.replaceFirst(Regex("(?i)^remind me\\s+(to\\s+)?"), "").trim()
        if (body.isBlank()) {
            return ActionOutcome.Failure("Tell me what to remind you about, e.g. \"Remind me to study at 6 PM\".")
        }

        val triggerAtMillis = TimeParser.extractFutureMillis(body)
            ?: return ActionOutcome.Failure(
                "I couldn't figure out the time. Try something like \"Remind me to study at 6 PM\" " +
                    "or \"Remind me to stretch in 20 minutes\"."
            )

        val taskText = TimeParser.stripTimePhrase(body)

        return when (val result = reminderScheduler.schedule(taskText, triggerAtMillis)) {
            is ScheduleResult.Scheduled -> {
                val fmt = SimpleDateFormat("h:mm a 'on' MMM d", Locale.getDefault())
                ActionOutcome.Success(
                    "Got it — I'll remind you to \"$taskText\" at ${fmt.format(result.reminder.triggerAtMillis)}."
                )
            }
            ScheduleResult.MissingExactAlarmPermission -> ActionOutcome.NeedsExactAlarmSettings(command)
            is ScheduleResult.Failed -> ActionOutcome.Failure("Couldn't schedule that reminder: ${result.reason}")
        }
    }

    // ---------------------------------------------------------------------
    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
}
