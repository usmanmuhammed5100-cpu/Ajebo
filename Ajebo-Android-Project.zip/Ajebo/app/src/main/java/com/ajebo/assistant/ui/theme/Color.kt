package com.ajebo.assistant.ui.theme

import androidx.compose.ui.graphics.Color

val AjeboPurple = Color(0xFF6C4AB6)
val AjeboPurpleDark = Color(0xFF4A2E9C)
val AjeboTeal = Color(0xFF2FBF9F)

val AjeboBgLight = Color(0xFFF7F6FB)
val AjeboBgDark = Color(0xFF121016)

val AjeboSurfaceLight = Color(0xFFFFFFFF)
val AjeboSurfaceDark = Color(0xFF1E1B24)

val AjeboBubbleUserLight = Color(0xFF6C4AB6)
val AjeboBubbleAiLight = Color(0xFFEDEAF6)
val AjeboBubbleUserDark = Color(0xFF7C5AC6)
val AjeboBubbleAiDark = Color(0xFF2A2632)

val AjeboError = Color(0xFFD64545)
val AjeboOnPurple = Color(0xFFFFFFFF)
