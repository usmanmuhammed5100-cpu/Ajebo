package com.ajebo.assistant.reminders

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * AlarmManager alarms are cleared by the OS on reboot, so any reminder the user set
 * before restarting their phone would silently vanish. This receiver reads the
 * reminders persisted by ReminderScheduler and re-arms every one still in the future.
 * Reminders whose time already passed while the phone was off fire immediately instead
 * of being lost, matching what the user actually asked for.
 *
 * Uses goAsync() because the re-arming work is asynchronous (DataStore + AlarmManager
 * calls): without it, Android is free to kill this receiver's process the instant
 * onReceive() returns, which — since a plain fire-and-forget coroutine returns
 * immediately — could silently drop every reminder on a slow boot. goAsync() keeps
 * the process alive (up to ~10s, which is plenty here) until finish() is called.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val appContext = context.applicationContext
        val scheduler = ReminderScheduler(appContext)
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val reminders = scheduler.getAllPersisted()
                val now = System.currentTimeMillis()

                reminders.forEach { reminder ->
                    if (reminder.triggerAtMillis > now) {
                        scheduler.schedule(reminder.text, reminder.triggerAtMillis)
                    } else {
                        // Missed while the device was off: fire it now if notifications are allowed.
                        if (NotificationManagerCompat.from(appContext).areNotificationsEnabled()) {
                            val fireIntent = Intent(appContext, ReminderReceiver::class.java).apply {
                                putExtra(ReminderReceiver.EXTRA_TEXT, reminder.text)
                                putExtra(ReminderReceiver.EXTRA_ID, reminder.id)
                            }
                            appContext.sendBroadcast(fireIntent)
                        }
                        scheduler.clearPersisted(reminder.id)
                    }
                }
            } catch (e: Exception) {
                // Best-effort re-arming; a failure here shouldn't crash the boot sequence.
            } finally {
                pendingResult.finish()
            }
        }
    }
}
