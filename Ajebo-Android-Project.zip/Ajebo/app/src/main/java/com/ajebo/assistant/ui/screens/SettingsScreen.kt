package com.ajebo.assistant.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    ttsEnabled: Boolean,
    darkTheme: Boolean,
    backendUrl: String,
    apiKeyOverride: String,
    onTtsToggle: (Boolean) -> Unit,
    onDarkThemeToggle: (Boolean) -> Unit,
    onSaveBackendUrl: (String) -> Unit,
    onSaveApiKey: (String) -> Unit,
    onClearChat: () -> Unit,
    onBack: () -> Unit
) {
    var urlField by remember(backendUrl) { mutableStateOf(backendUrl) }
    var keyField by remember(apiKeyOverride) { mutableStateOf(apiKeyOverride) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(16.dp)
        ) {
            item { SectionHeader("AI / API Settings") }
            item {
                Text(
                    "Recommended: point Ajebo at your own backend proxy, which keeps your Claude " +
                        "API key off the device entirely. See the project's /backend folder.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = urlField,
                    onValueChange = { urlField = it },
                    label = { Text("Backend proxy URL") },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("https://your-backend.example.com/api/chat") }
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Dev-only alternative: a direct API key stored only on this device " +
                        "(insecure for any app you share with others).",
                    style = MaterialTheme.typography.labelSmall
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = keyField,
                    onValueChange = { keyField = it },
                    label = { Text("Dev API key (optional)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        onSaveBackendUrl(urlField.trim())
                        onSaveApiKey(keyField.trim())
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Save AI configuration") }
            }

            item { Spacer(Modifier.height(24.dp)) }
            item { Divider() }
            item { SectionHeader("Voice") }
            item {
                SettingRow(
                    label = "Text-to-speech responses",
                    checked = ttsEnabled,
                    onCheckedChange = onTtsToggle
                )
            }

            item { Spacer(Modifier.height(8.dp)) }
            item { Divider() }
            item { SectionHeader("Appearance") }
            item {
                SettingRow(
                    label = "Dark theme",
                    checked = darkTheme,
                    onCheckedChange = onDarkThemeToggle
                )
            }

            item { Spacer(Modifier.height(8.dp)) }
            item { Divider() }
            item { SectionHeader("Conversation") }
            item {
                Button(onClick = onClearChat, modifier = Modifier.fillMaxWidth()) {
                    Text("Clear conversation")
                }
            }

            item { Spacer(Modifier.height(8.dp)) }
            item { Divider() }
            item { SectionHeader("Permissions & help") }
            item {
                Text(
                    "• Microphone — needed for voice commands.\n" +
                        "• Phone — needed to place calls when you say \"Call X\".\n" +
                        "• Contacts — needed to look up a contact's number.\n" +
                        "• Notifications — needed so reminders can alert you.\n" +
                        "• Alarms & reminders — Android 12+ requires this special access, " +
                        "granted from system Settings, to schedule exact reminder alarms.\n\n" +
                        "Ajebo only requests a permission right when it's needed for the action " +
                        "you asked for, and explains why before asking.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            item { Spacer(Modifier.height(8.dp)) }
            item { Divider() }
            item { SectionHeader("About Ajebo") }
            item {
                Text(
                    "Ajebo is a personal AI assistant for Android. It understands typed and " +
                        "spoken commands, chats using the Claude API, and can perform real phone " +
                        "actions — calling, messaging, opening apps, searching, and setting " +
                        "reminders — using standard Android APIs and intents.\n\nVersion 1.0",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        modifier = Modifier.padding(vertical = 12.dp)
    )
}

@Composable
private fun SettingRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
