# Ajebo — Personal AI Assistant for Android

A real, buildable Android Studio project: Kotlin + Jetpack Compose, AI chat via
Claude, voice input/output, and actual phone actions (calling, messaging,
opening apps, reminders, web search) performed through standard Android APIs
and intents.

## Project structure

```
Ajebo/
├── app/
│   ├── build.gradle
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/ajebo/assistant/
│       │   ├── AjeboApplication.kt          # notification channel setup
│       │   ├── MainActivity.kt              # Compose host, permissions, speech/TTS lifecycle
│       │   ├── ai/
│       │   │   ├── ApiConfig.kt             # resolves backend/dev-key config, no hardcoded secrets
│       │   │   └── ClaudeApiClient.kt       # talks to backend proxy or Anthropic API directly
│       │   ├── speech/
│       │   │   ├── SpeechRecognitionManager.kt
│       │   │   └── TextToSpeechManager.kt
│       │   ├── actions/
│       │   │   ├── PhoneActionHandler.kt    # command parsing + real Android intents/APIs
│       │   │   └── TimeParser.kt            # "at 6 PM" / "in 20 minutes" parsing
│       │   ├── reminders/
│       │   │   ├── ReminderScheduler.kt     # AlarmManager scheduling + persistence
│       │   │   ├── ReminderReceiver.kt      # fires the notification when due
│       │   │   └── BootReceiver.kt          # re-arms reminders after reboot
│       │   ├── data/
│       │   │   ├── Message.kt
│       │   │   ├── SettingsRepository.kt    # DataStore-backed preferences
│       │   │   └── ChatViewModel.kt         # app state + orchestration
│       │   └── ui/
│       │       ├── theme/ (Color.kt, Theme.kt, Type.kt)
│       │       ├── components/MessageBubble.kt
│       │       └── screens/ (ChatScreen.kt, SettingsScreen.kt)
│       └── res/
│           ├── values/ (strings.xml, colors.xml, themes.xml)
│           ├── drawable/ (launcher icon layers, notification icon)
│           ├── mipmap-anydpi-v26/ (adaptive launcher icon)
│           └── xml/network_security_config.xml
├── backend/                       # OPTIONAL but recommended: secure Claude proxy
│   ├── server.js
│   ├── package.json
│   ├── .env.example
│   └── README.md
├── build.gradle
├── settings.gradle
├── gradle.properties
├── local.properties.example       # copy to local.properties, fill in your config
└── README.md                      # this file
```

## Exact versions required

| Tool | Required version | Notes |
|---|---|---|
| Android Studio | Koala (2024.1) or newer | Ships a bundled JDK 17, which this project needs |
| JDK | 17 | Set explicitly in `app/build.gradle` (`sourceCompatibility`/`targetCompatibility`/`jvmTarget`) |
| Android Gradle Plugin (AGP) | 8.5.0 | Declared in root `build.gradle` |
| Gradle | 8.7 | Declared in `gradle/wrapper/gradle-wrapper.properties` |
| Kotlin | 1.9.24 | Declared in root `build.gradle` |
| Compose Compiler extension | 1.5.14 | Declared in `app/build.gradle`; matches Kotlin 1.9.24 |
| compileSdk / targetSdk | 34 (Android 14) | Declared in `app/build.gradle` |
| minSdk | 24 (Android 7.0) | Comfortably covers Android 10 / low-end devices like the TECNO Spark 4 |

## Opening and building the project

1. Install **Android Studio Koala (2024.1) or newer** — it bundles the JDK 17
   this project requires, so you shouldn't need to install a JDK separately.
2. Copy this whole `Ajebo/` folder onto your machine and open it in Android
   Studio via **File → Open**, pointing at the `Ajebo/` folder (the one
   containing `settings.gradle`).
3. **Gradle wrapper jar**: this project ships `gradlew`, `gradlew.bat`, and
   `gradle/wrapper/gradle-wrapper.properties` (pinning Gradle 8.7), but **not**
   the binary `gradle-wrapper.jar` — it can't be produced without a network
   connection in the environment this project was generated in. You need it
   once before the first build. Pick whichever is easiest for you:
   - **Easiest**: open the project in Android Studio and let it sync. Modern
     Android Studio detects an incomplete wrapper and offers to regenerate it
     using its own bundled Gradle — accept that prompt.
   - **If it doesn't prompt you**, open a terminal in the project root and, if
     you have any Gradle installed locally (`brew install gradle`, `sdk
     install gradle`, or similar), run:
     ```bash
     gradle wrapper --gradle-version 8.7
     ```
     This writes the missing `gradle-wrapper.jar` to match the existing
     `gradle-wrapper.properties`, after which `./gradlew` works normally.
   - **Alternative**: in Android Studio, go to *Settings → Build, Execution,
     Deployment → Build Tools → Gradle* and temporarily set "Gradle JVM" /
     project Gradle to "Use Gradle from: 'specified location'" pointing at any
     locally installed Gradle 8.7+, sync once, then switch back to the wrapper.
4. Copy `local.properties.example` → `local.properties` in the project root.
   Android Studio fills in `sdk.dir` for you on first sync; you fill in the AI
   configuration (see below).
5. **Build → Make Project**, or from a terminal:
   ```bash
   ./gradlew assembleDebug
   ```
   The debug APK lands at `app/build/outputs/apk/debug/app-debug.apk` — a real,
   installable Android package, not a web app or PWA. Install it on a device
   with `./gradlew installDebug` (device connected via USB debugging), or drag
   the APK onto an emulator.

## Errors that could still occur (not verifiable without a real compiler)

This project was written and manually cross-checked line-by-line in a sandbox
with **no Android SDK and no network access**, so it could not be run through
an actual `gradlew build`. Every file was checked by hand for package/import
correctness, manifest-component wiring, resource-reference consistency, and
known Android platform gotchas (see the fixes list below). That said, be aware
these categories of problem are the ones most likely to still surface:

- **Compose/Material3 API drift** — if you use a much newer Compose BOM than
  `2024.06.00`, a handful of Material3 component parameter names occasionally
  change between versions (e.g. `Divider` → `HorizontalDivider` in newer
  Material3 releases). If you bump the BOM version, watch for deprecation/
  removal warnings on `Divider` in `SettingsScreen.kt`.
- **Gradle/AGP version drift** — if Android Studio auto-upgrades the AGP or
  Gradle version on sync (it sometimes prompts to), keep JDK 17 and the
  version pairing above in mind; jumping AGP major versions can require
  further `build.gradle` syntax changes this project doesn't include.
- **Device-specific OEM restrictions** — some OEM Android skins (including
  Tecno's HiOS, which the Spark 4 ships with) apply aggressive background/
  battery-optimization killing that can delay `BootReceiver`'s reminder
  re-arming after boot, or throttle background alarms. This is an OEM
  behavior outside any app's control; if reminders feel unreliable on such a
  device, check the device's battery-optimization exemption list for Ajebo.


## Connecting Ajebo to Claude (API key security)

**Ajebo never contains a hardcoded API key in source.** You choose one of two
setups, configured in `local.properties` (build-time) and/or in the app's own
**Settings → AI/API Settings** screen (runtime, stored in DataStore on-device):

### Option A — Backend proxy (recommended, secure)
Deploy the small server in `/backend` (Node/Express) somewhere that can hold a
secret environment variable — Render, Railway, Fly.io, your own VPS, etc. It
holds your real Anthropic API key server-side and forwards chat requests.
Point Ajebo at it via `AJEBO_BACKEND_URL` in `local.properties`, or by typing
the URL into Settings on-device. See `backend/README.md` for full deploy
steps. This is the only setup that's safe for an APK you hand to someone else,
since nothing in the app itself can leak the key.

### Option B — Direct dev key (local testing only, NOT secure to distribute)
Set `CLAUDE_API_KEY` in `local.properties` for quick local testing on your own
device. This gets compiled into `BuildConfig`, which **can be extracted by
decompiling the APK** — fine for your own dev phone, unsafe for anyone else's.

If neither is configured, the app runs fully (chat UI, voice, phone actions)
but shows a clear in-chat message explaining AI chat isn't connected yet, with
where to configure it.

## What actually works (and how)

| Command example | Mechanism |
|---|---|
| "Call Mom" | Looks up the contact via `ContactsContract`, then `Intent.ACTION_CALL` (needs `CALL_PHONE` + `READ_CONTACTS`, requested at the moment they're needed with an explanation) |
| "Text John saying I'm late" | `Intent.ACTION_SENDTO` (`smsto:`) opens the user's own default messaging app pre-filled — Ajebo does not send SMS silently on your behalf |
| "Open WhatsApp / YouTube / Chrome" | `PackageManager.getLaunchIntentForPackage`, with a web fallback if the app isn't installed |
| "Open Settings" | `Intent(Settings.ACTION_SETTINGS)` |
| "Open Maps" / "Navigate to Eiffel Tower" | `geo:` URI `Intent.ACTION_VIEW`, preferring the Google Maps package |
| "Set an alarm for 6:30 AM" | `AlarmClock.ACTION_SET_ALARM` — hands off to the phone's own Clock app for user confirmation, the correct sanctioned way for a 3rd-party app to create a ringing alarm |
| "Remind me to study at 6 PM" | Parsed by `TimeParser`, scheduled with `AlarmManager.setExactAndAllowWhileIdle`, fires a real notification via `ReminderReceiver`; persisted so `BootReceiver` re-arms it after a restart |
| "Search for cheap flights" | `Intent.ACTION_WEB_SEARCH` with a browser fallback |
| "Play [song/artist]" | Launches an installed music app if found, else `MediaStore.INTENT_ACTION_MUSIC_PLAYER` |
| "Open [any installed app]" | Matches against installed app labels via `PackageManager` |
| "Show contacts" | `Intent.ACTION_VIEW` on `ContactsContract.Contacts.CONTENT_URI` |
| "What's the time/date" | Answered directly, no intent needed |
| Anything else | Falls through to normal Claude conversation |

Every `Success` message shown in chat corresponds to Android actually having
performed the action (started the activity, scheduled the alarm, etc.) — the
handler never fabricates a success message for something that didn't happen.

## Permissions requested, and why

Requested **just-in-time**, at the moment an action needs them, with an
explanation shown first:

- `RECORD_AUDIO` — voice input (mic button)
- `CALL_PHONE`, `READ_CONTACTS` — placing calls by contact name
- `POST_NOTIFICATIONS` (Android 13+) — so reminders can alert you; requested
  once at first launch since there's no natural per-action moment for it
- `SCHEDULE_EXACT_ALARM` / "Alarms & reminders" special access (Android 12+)
  — there is no runtime dialog for this; Ajebo detects when it's missing and
  deep-links to the exact system Settings screen to grant it

## Known Android platform limitations (and what Ajebo does instead)

- **Becoming the phone's system-wide voice assistant** (replacing Google
  Assistant, answering from the lock screen via a hardware button) requires
  implementing `VoiceInteractionService`/`VoiceInteractionSessionService`,
  device-list allowlisting, and is a much larger, OEM-dependent undertaking
  outside a normal app's scope. Ajebo instead provides its own in-app mic
  button using the standard `SpeechRecognizer` API, which any app can use.
- **Sending SMS silently with `SmsManager.sendTextMessage`** is technically
  possible with the `SEND_SMS` permission, but Ajebo deliberately uses
  `ACTION_SENDTO` instead so the user's own messaging app sends it — this
  avoids a highly sensitive permission and matches the requirement to never
  fake or silently perform an action the user didn't directly confirm.
- **Exact alarms on Android 12+** need explicit "Alarms & reminders" access
  granted in system Settings (not a runtime permission dialog); Ajebo detects
  this and routes the user there directly instead of failing silently.

## Low-end device compatibility

- `minSdk 24` (Android 7+), tested conceptually against Android 10 behavior.
- No Material You dynamic color (skips wallpaper-sampling overhead).
- Minimal dependency set: Compose BOM, OkHttp, org.json, DataStore — no heavy
  image/animation/DI libraries.
- Lazy list rendering for chat history; TTS/speech recognizer objects are
  created only when actually used and torn down in `onDestroy`.
